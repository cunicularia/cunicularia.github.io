library(svDialogs)
# Updating instructions: Look out for these numbers...
# 2016: Refers to the greatest year users can input before there is nothing to graph. 
# 2017: Refers to the exclusive limit of years that user can input before there is nothing to graph.
# 111: Refers to the last column in the records CSV referencing a species in Beaver Lake. Just add 1 to it for every new species seen in the site.
# 140: Refers to the last column in the records CSV referencing a species in Lost Lagoon. Just add 1 to it for every new species seen in the site.
# 156: Refers to December 2017 -- the last month of the last complete year. Just add 1 for every extra year.
# 157: Refers to January 2018 -- the last month with survey data in the spreadsheets. Just add 1 for every added month after that.
richness <- function() {
  # Resets the par to default so that only one graph is made, seeing as graph3() messed with it.
  par(mfrow=c(1,1))
  recordsBL <- read.csv("BeaverLake_Abundance.csv")
  recordsLL <- read.csv("LostLagoon_Abundance.csv")
  info_boxLL <- read.csv("LostLagoon_Info.csv")
  info_boxBL <- read.csv("BeaverLake_Info.csv")
  cancelled <- function() {
    dlgMessage("No problem! ^_^")$res
    stop("Function was cancelled.")
  }
  # questions() grabs the user's input for a bunch of different things. These things are then plugged into rich_graph(), which subsequently plugs them into mini_richness() to grab the richness values of a month for the picked taxon. The output of mini_richness() is then graphed by mini_graph().
  questions <- function() {
    searched_site <- dlgList(c("Lost Lagoon","Beaver Lake"),preselect = NULL, multiple = FALSE, title = "Site Options n_n", gui = .GUI)$res
    if (!length(searched_site)) {
      cancelled()
    }
    else if (searched_site == "Lost Lagoon") {
      records <- recordsLL
      info_box <- info_boxLL
    }
    else if (searched_site == "Beaver Lake") {
      records <- recordsBL
      info_box <- info_boxBL
    }
    searched_type <- dlgList(c("All Birds","Specific Groups"),preselect = NULL, multiple = FALSE, title = "Type Options n_n", gui = .GUI)$res
    if (!length(searched_type)) {
      cancelled()
    }
    else if (searched_type == "All Birds") {
      searched_group <- "None"
      searched_subset <- "All Birds"
    }
    else if (searched_type == "Specific Groups") {
      searched_group <- dlgList(c("Tier 2","Tier 3","Disturbances","Cavity Nester","At-Risk","Order","Family"),preselect = NULL, multiple = FALSE, title = "Tier Options n_n", gui = .GUI)$res
      if (!length(searched_group)) {
        cancelled()
      }
      else if (searched_group == "Tier 2") {
        searched_subset <- dlgList(c("Raptors","NA Waterbirds","Anseriformes","Passeriformes","Hummingbirds","Columbiformes","Piciformes"),preselect = NULL, multiple = FALSE, title = "Tier 2 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Tier 3") {
        searched_subset <- dlgList(c("Kingfishers","Loons & Grebes","Pelecaniformes","Rallidae","Sea Birds","Shorebirds","Ducks, Dabbling","Ducks, Diving","Ducks, Perching","Ducks, Sea","Geese & Swans","Aerial Insectivores","Forest Birds","Disturbance-adapted"),preselect = NULL, multiple = FALSE, title = "Tier 3 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Disturbances") {
        searched_subset <- dlgList(c("Disturbance-habituated","Non-disturbance-habituated"),preselect = NULL, multiple = FALSE, title = "Disturbance Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "At-Risk") {
        searched_subset <- dlgList(c("At-Risk","Non-At-Risk"),preselect = NULL, multiple = FALSE, title = "At-Risk Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Cavity Nester") {
        searched_subset <- dlgList(c("All","All Primary","Strong Primary","Weak Primary","Secondary"),preselect = NULL, multiple = FALSE, title = "Cavity Nester Options n_n", gui = .GUI)$res
      }
      # column_check denotes the columns for Order and Family in info_box. The next few lines check whether the user-inputted taxon is in the columns.
      else if (searched_group == "Order" || searched_group == "Family") {
        if (searched_group == "Order") {
          example <- "Passeriformes"
          column_check <- 3
        }
        else if (searched_group == "Family") {
          example <- "Rallidae"
          column_check <- 4
        }
        searched_subset <- dlgInput("What taxon are you interested in?",example)$res
        if (!length(searched_subset)) {
          cancelled()
        }
        else if (searched_subset %in% info_box[,column_check]) {
          searched_subset <- searched_subset
        }
        # If the user input isn't recognized, they will be stuck in a loop until they input a valid one or cancel the function.
        else {
          error_loop <- function() {
            dlgMessage("Sorry, that species was not found in the records. Please search again or cancel.")
            searched_subset <- dlgInput("What's the code of the taxon you're interested in?", searched_subset)$res
            if (!length(searched_subset)) {
              cancelled()
            }
            else if (searched_subset %in% info_box[,column_check]) {
              searched_subset <- searched_subset
            }
            else {
              error_loop()
            }
          }
          searched_subset <- error_loop()
        }
      }
    }
    answers <- c(searched_site,searched_type,searched_group,searched_subset)
  }
  answers <- questions()
  rich_graph <- function(site, type, group, subset) {
    print("Double-checking (for troubleshooting) n_n")
    print(noquote("_________________________________________"))
    print(paste("Site:",site))
    print(paste("Type:",type))
    print(paste("Group:",group))
    print(paste("Group Subset:",subset))
    mini_graph <- function(dates,data,group,subset,site) {
      # Adjusts the final graph title for special cases, especially 'All Cavity Nesters', 'Non-disturbance-habituated", and 'Non-At-Risk'.
      if (group == "Cavity Nester" || group == "Disturbances" || group == "At-Risk") {
        if (group == "Cavity Nester") {
          if (subset == "Primary|Secondary") {
            subset <- "All"
          }
          adjusted_title <- paste(subset," Cavity Nesters",sep="")
        }
        else {
          if (group == "Disturbances" && subset == "No") {
            subset <- "Non-disturbance-habituated"
          }
          else if (group == "At-Risk" && subset == "No") {
            subset <- "Non-At-Risk"
          }
          adjusted_title <- paste(subset," Birds",sep="")
        }
      }
      else {
        adjusted_title <- subset
      }
      final_adjusted_title <- paste(adjusted_title," at ",site," (Richness)",sep="")
      ticks <- seq(0,156, by=12)
      plot_type_string <- dlgList(c("Points only","Line only","Points and Line"),preselect = NULL, multiple = FALSE, title = "Graph Options n_n", gui = .GUI)$res
      if (!length(plot_type_string)) {
        cancelled()
      }
      else if (plot_type_string == "Points only") {
        plot_type_translated <- "p"
      }
      else if (plot_type_string == "Line only") {
        plot_type_translated <- "l"
      }
      else if (plot_type_string == "Points and Line") {
        plot_type_translated <- "o"
      }
      plot(dates,data, main=final_adjusted_title, type=plot_type_translated, xlab = "Date Code (1 = Jan 2005, 2 = Feb 2005)",ylab = "Total # of Species Seen", xlim = c(1,157), xaxt = "n")
      axis(side=1,at=ticks)
      abline(v=ticks,col="lightgray")
    }
    # mini_richness() uses the inputted species (denoted by their column numbers in the records CSV) and checks if they were seen in a specific month. If they were, they are counted.
    mini_richness <- function(site, type, month, group_column_numbers) {
      if (site == "Lost Lagoon") {
        records <- recordsLL
        all_species_length <- c(4:140)
      }
      else if (site == "Beaver Lake") {
        records <- recordsBL
        all_species_length <- c(4:111)
      }
      if (type == "All Birds") {
        species_columns <- all_species_length
      }
      else if (type == "Specific Groups") {
        species_columns <- group_column_numbers
      }
      richness_value <- 0
      for (species in species_columns) {
        indiv_richness <- records[month,species] 
        if (!is.na(indiv_richness) && indiv_richness > 0) {
          richness_value <- richness_value + 1 
        }
      }
      monthly_richness <- richness_value
    }
   if (type == "All Birds") {
     all_richness_data <- c()
     all_richness_dates <- c()
     for (month in 1:157) {
       all_richness_data <- c(all_richness_data,mini_richness(site, type, month, "None"))
       all_richness_dates <- c(all_richness_dates,month)
     }
     mini_graph(all_richness_dates, all_richness_data, group, subset, site)
   }
    else if (type == "Specific Groups") {
      subset_cavity_actual <- "None"
      if (site == "Lost Lagoon") {
        info_box <- info_boxLL
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        info_box <- info_boxBL
        records <- recordsBL
      }
      if (group == "Order") {
        tier_column_number <- 3
      }
      else if (group == "Family") {
        tier_column_number <- 4
      }
      else if (group == "Tier 2") {
        tier_column_number <- 5
      }
      else if (group == "Tier 3") {
        tier_column_number <- 6
      }
      else if (group == "Disturbances") {
        tier_column_number <- 7
        if (subset == "Non-disturbance-habituated") {
          subset <- "No"
        }
      }
      else if (group == "Cavity Nester") {
        tier_column_number <- 8
        # To find all primary cavity nesters, all cavity nester categories containing the word 'Primary' are grabbed.
        if (subset == "All Primary") {
          subset_cavity_actual <- subset
          subset <- "Primary"
        }
        # If a cavity nester category has 'Primary' or 'Secondary' in the name, they are grabbed.
        else if (subset == "All") {
          subset_cavity_actual <- subset
          all <- c("Primary","Secondary")
          subset <- paste(all, collapse = "|")
        }
      }
      else if (group == "At-Risk") {
        tier_column_number <- 9
        if (subset == "Non-At-Risk") {
          subset <- "No"
        }
      }
      # For the searched tier's column number in info_box, the searched group is looked for. Rows that correspond to member of the group are grabbed.
      # The row numbers are translated to alpha codes.
      # These alpha codes are then corresponded to column numbers in the records CSV. 
      # These column numbers are inputted into mini_richness() for each month.
      group_row_number <- which(grepl(subset,info_box[,tier_column_number]))
      group_code_factor <- info_box[group_row_number,1]
      group_code_string <- as.character(group_code_factor)
      group_code_length <- length(group_code_string)
      group_column_numbers <- c()
      for (i in 1:group_code_length) {
        group_subset <- group_code_string[i]
        group_subset_column_number <- which(grepl(group_subset,names(records)))
        group_column_numbers <- c(group_column_numbers,group_subset_column_number)
      }
      group_richness_data <- c()
      group_richness_dates <- c()
      for (month in 1:157) {
        group_richness_data <- c(group_richness_data,mini_richness(site, type, month, group_column_numbers))
        group_richness_dates <- c(group_richness_dates,month)
      }
      # I didn't want to clog up the console, so if there are too many group members to print for double-checking/comparison purposes, I prevented it.
      if (group_code_length <= 20) {
        print(noquote("--------"))
        print("Lost Lagoon Group Members:")
        print(colnames(recordsLL)[group_column_numbers])
        print(noquote("--------"))
        print("Beaver Lake Group Members:")
        print(colnames(recordsBL)[group_column_numbers])
        print(noquote("--------"))
        print("Searched Group Members:")
        print(colnames(records)[group_column_numbers])
      }
      else {
        print("Searched Group Members: N/A; too many group members to print Q~Q")
      }
      mini_graph(group_richness_dates,group_richness_data,group,subset,site)
    }
  }
  rich_graph(answers[1],answers[2],answers[3],answers[4])
  print(noquote("--------"))
  print("Thanks for graphing! d(*o*)b ")
}