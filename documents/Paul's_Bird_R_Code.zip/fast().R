library(svDialogs)
fast <- function(site,plot_type) {
  # Resets par so that only one graph is plotted at a time.
  par(mfrow=c(1,1))
  recordsBL <- read.csv("BeaverLake_Abundance.csv")
  recordsLL <- read.csv("LostLagoon_Abundance.csv")
  info_boxLL <- read.csv("LostLagoon_Info.csv")
  info_boxBL <- read.csv("BeaverLake_Info.csv")
  cancelled <- function() {
    dlgMessage("No problem! ^_^")$res
    stop("Function was cancelled.")
  }
  # Something I took from stackoverflow; it's stop() but without any error message printed.
  stop_quietly <- function() {
    opt <- options(show.error.messages = FALSE)
    on.exit(options(opt))
    stop()
  }
  # mini_graph() takes in dates and data and plots them together.
  mini_graph <- function(dates,data,species_number,site,plot_type) {
    title_code <- colnames(records)[species_number]
    title_final <- paste(title_code," (",species_number,") ","at ",site,sep="")
    ticks <- seq(0,156, by=12)
    plot(dates,data, main=title_final, type=plot_type, xlab = "Date Code (1 = Jan 2005, 2 = Feb 2005)", ylab = "Total # of Individuals Seen", xlim = c(0,157), xaxt = "n")
    axis(side=1,at=ticks)
    abline(v=ticks,col="lightgray")
  }
  # Default value for site_valid is set. XX_valid objects check if the site/plot_type is invalid.
  site_valid <- "Yes"
  site_check <- toupper(site) 
  if (site_check == "LL" || site_check == "LOSTLAGOON" || site_check == "LOST LAGOON") {
    site <- "Lost Lagoon"
    records <- recordsLL
    info_box <- info_boxLL
  }
  else if (site_check == "BL" || site_check == "BEAVERLAKE" || site_check == "BEAVER LAKE") {
    site <- "Beaver Lake"
    records <- recordsBL
    info_box <- info_boxBL
  }
  # site_valid == 'No' if it doesn't resemble any valid variation of the two sites' names.
  else {
    site_valid <- "No"
  }
  plot_type_valid <- "Yes"
  plot_type_check <- tolower(plot_type)
  if (plot_type_check == "p" || plot_type_check == "l" || plot_type_check == "o") {
    plot_type <- plot_type_check
  }
  else {
    plot_type_valid <- "No"
  }
  if (site_valid == "No" || plot_type_valid == "No") {
    # fast() is later called with site_new and plot_type_new as parameters. The next two lines ensures that the any correct user inputs will be called then.
    site_new <- site
    plot_type_new <- plot_type
    # double_error for fancier error messages. I wanted to play around with them. 
    double_error <- ""
    if (site_valid == "No") {
      dlgMessage(paste("There was an error with the site.","Please enter it like 'LL','lostlagoon', or 'Lost Lagoon'.",sep="\n"))
      double_error == "also "
    }
    if (plot_type_valid == "No") {
      double_error_message <- paste("There was ",double_error,"an error with the plot type.",sep="")
      dlgMessage(paste(double_error_message,"Please enter 'p' for points only, 'l' for line only, or 'o' for both lines and points.",sep="\n"))
    }
    if (site_valid == "No") {
      site_new <- dlgInput("Please re-enter a site.")$res
      if (!length(site_new)) {
        cancelled()
      }
    }
    if (plot_type_valid == "No") {
      plot_type_new <- dlgInput("Please re-enter a plot type.")$res
      if (!length(plot_type_new)) {
        cancelled()
      }
    }
    fast(site_new,plot_type_new)
    # stop_quietly() needs to be called or else fast() will be called twice; both with site_new/plot_type_new and the original parameters.
    stop_quietly()
  }
  # species_grabber() takes in the species number that the user wants and makes sure it's valid.
  species_grabber <- function(site) {
    if (site == "Lost Lagoon") {
      info_box <- info_boxLL
    }
    else if (site == "Beaver Lake") {
      info_box <- info_boxBL
    }
    # svDialogs takes in all input as strings, so I have to convert it to numeric.
    # Should letters be inputted by the user, is.na() catches it.
    # Should inputs not be valid, species_grabber() loops back.
    species_number_string <- dlgInput("Input species code. Cancel to stop the loop or pick another site.")$res
    species_number <- as.numeric(as.character(species_number_string))
    if (!length(species_number)) {
      cancelled()
    }
    else if (is.na(species_number) || species_number < 4 || species_number > length(info_box[,1])) {
      species_error_message <- paste("Please enter a number between 4 and ",length(info_box[,1]),".",sep="") 
      dlgMessage(paste("There was an error with the species code.",species_error_message,sep="\n"))$res
      species_grabber(site)
    }
    else {
      species_number <- species_number
    }
  }
  # After grabbing the species number (i.e. the column number for the records CSV), a for loop groups up all abundance data together.
  species_number <- species_grabber(site)
  individual_abundance_dates <- c()
  individual_abundance_data <- c()
  for (month in 1:157) {
    individual_abundance_data <- c(individual_abundance_data,records[month,species_number])
    individual_abundance_dates <- c(individual_abundance_dates,month)
  }
  mini_graph(individual_abundance_dates,individual_abundance_data,species_number,site,plot_type)
  print(noquote("_______________________"))
  print(noquote("Summarizing"))
  print(noquote(paste("Site:",site)))
  print(noquote(paste("Plot Type:",plot_type)))
  print(noquote(paste("Column Number: ",species_number)))
  print(noquote(paste("Code: ", colnames(records)[species_number])))
  print(noquote("_______________________"))
}