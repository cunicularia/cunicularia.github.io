library(svDialogs)
# Updating instructions: Look out for these numbers...
# 2016: Refers to the greatest year users can input before there is nothing to graph. 
# 2017: Refers to the exclusive limit of years that user can input before there is nothing to graph.
# 111: Refers to the last column in the records CSV referencing a species in Beaver Lake. Just add 1 to it for every new species seen in the site.
# 140: Refers to the last column in the records CSV referencing a species in Lost Lagoon. Just add 1 to it for every new species seen in the site.
# 156: Refers to December 2017 -- the last month of the last complete year. Just add 1 for every extra year.
# 157: Refers to January 2018 -- the last month with survey data in the spreadsheets. Just add 1 for every added month after that.
graph3 <- function() {
  # Reset par since graph3() might've changed the value.
  par(mfrow=c(1,1))
  recordsBL <- read.csv("BeaverLake_Abundance.csv")
  recordsLL <- read.csv("LostLagoon_Abundance.csv")
  info_boxLL <- read.csv("LostLagoon_Info.csv")
  info_boxBL <- read.csv("BeaverLake_Info.csv")
  # Whenever the user doesn't input anything, this will be called to stop the function and print a message.
  cancelled <- function() {
    dlgMessage("No problem! ^_^")$res
    stop("Function was cancelled.")
  }
  # questions() grabs the user input for a site and species. 
  # These are later used by abun_graph(), which uses it to graph the overall abundance with two more functions:
  # mini_abundance(), which grabs the abundance for all searched species/taxa; 
  # and mini_graph(), which mini_abundance() uses to graph the abundance.
  questions <- function() {
    searched_site <- dlgList(c("Lost Lagoon","Beaver Lake"),preselect = NULL, multiple = FALSE, title = "Site Options n_n", gui = .GUI)$res
    if (!length(searched_site)) {
      cancelled()
    }
    # I got really paranoid about the correct site CSV being used, so there's going to be a bunch of these redundant bits.
    else if (searched_site == "Lost Lagoon") {
      records <- recordsLL
      info_box <- info_boxLL
    }
    else if (searched_site == "Beaver Lake") {
      records <- recordsBL
      info_box <- info_boxBL
    }
    searched_type <- dlgList(c("All Birds","Specific Groups", "Individual Species"),preselect = NULL, multiple = FALSE, title = "Type Options n_n", gui = .GUI)$res
    if (!length(searched_type)) {
      cancelled()
    }
    else if (searched_type == "All Birds") {
      searched_group <- "None"
      searched_subset <- "All Birds"
    }
    else if (searched_type == "Specific Groups") {
      searched_group <- dlgList(c("Tier 2","Tier 3","Disturbances","Cavity Nester","At-Risk","Order","Family"),preselect = NULL, multiple = FALSE, title = "Tier Options n_n", gui = .GUI)$res
      if (!length(searched_group)) {
        cancelled()
      }
      else if (searched_group == "Tier 2") {
        searched_subset <- dlgList(c("Raptors","NA Waterbirds","Anseriformes","Passeriformes","Hummingbirds","Columbiformes","Piciformes"),preselect = NULL, multiple = FALSE, title = "Tier 2 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Tier 3") {
        searched_subset <- dlgList(c("Kingfishers","Loons & Grebes","Pelecaniformes","Rallidae","Sea Birds","Shorebirds","Ducks, Dabbling","Ducks, Diving","Ducks, Perching","Ducks, Sea","Geese & Swans","Aerial Insectivores","Forest Birds","Disturbance-adapted"),preselect = NULL, multiple = FALSE, title = "Tier 3 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Disturbances") {
        searched_subset <- dlgList(c("Disturbance-habituated","Non-disturbance-habituated"),preselect = NULL, multiple = FALSE, title = "Disturbance Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "At-Risk") {
        searched_subset <- dlgList(c("At-Risk","Non-At-Risk"),preselect = NULL, multiple = FALSE, title = "At-Risk Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Cavity Nester") {
        searched_subset <- dlgList(c("All","All Primary","Strong Primary","Weak Primary","Secondary"),preselect = NULL, multiple = FALSE, title = "Cavity Nester Options n_n", gui = .GUI)$res
      }
      # column_check refers to the columns in info_box that contain the orders and families.
      # That'll be used to check whether the user input is valid.
      else if (searched_group == "Order" || searched_group == "Family") {
        if (searched_group == "Order") {
          example <- "Passeriformes"
          column_check <- 3
        }
        else if (searched_group == "Family") {
          example <- "Rallidae"
          column_check <- 4
        }
        searched_subset <- dlgInput("What taxon are you interested in?",example)$res
        if (!length(searched_subset)) {
          cancelled()
        }
        else if (searched_subset %in% info_box[,column_check]) {
          searched_subset <- searched_subset
        }
        # A loop is made so that the user can keep on trying to input the right taxon without stopping the function.
        else {
          error_loop <- function() {
            dlgMessage("Sorry, that taxon was not found in the records. Please search again or cancel.")
            searched_subset <- dlgInput("What's the code of the taxon you're interested in?", searched_subset)$res
            if (!length(searched_subset)) {
              cancelled()
            }
            else if (searched_subset %in% info_box[,column_check]) {
              searched_subset <- searched_subset
            }
            else {
              error_loop()
            }
          }
          searched_subset <- error_loop()
        }
      }
    }
    else if (searched_type == "Individual Species") {
      searched_group <- "None"
      # 'All Birds' is the default input just in case the user fat-fingered and wanted to search for all birds.
      # tbh it might've been just me.
      searched_subset <- dlgInput("What's the code of the species you're interested in?","All Birds")$res
      # The next line is for users who don't want to type the alpha code in all caps.
      capital_searched_subset <- toupper(searched_subset)
      if (!length(searched_subset)) {
        cancelled()
      }
      else if (searched_subset == "All Birds" || searched_subset %in% colnames(records)) {
        searched_subset <- searched_subset
      }
      else if (capital_searched_subset %in% colnames(records)) {
        searched_subset <- capital_searched_subset
      }
      # Species not in the records CSV? User is trapped in a loop until they cancel or input a valid one.
      else {
        error_loop <- function() {
          dlgMessage("Sorry, that species was not found in the records. Please search again or cancel.")
          # There's definitely a more efficient way to check the new input besides repeating code,
          # but I was a bit worried about losing myself in the code.
          searched_subset <- dlgInput("What's the code of the species you're interested in?", searched_subset)$res
          capital_searched_subset <- toupper(searched_subset)
          if (!length(searched_subset)) {
            cancelled()
          }
          else if (searched_subset == "All Birds" || searched_subset %in% colnames(records)) {
            searched_subset <- searched_subset
          }
          else if (capital_searched_subset %in% colnames(records)) {
            searched_subset <- capital_searched_subset
          }
          else {
            error_loop()
          }
        }
        searched_subset <- error_loop()
      }
    }
    # Placed here because 'All Birds' can be the subset via the 'Individual Species' and 'All Birds' route.
    if (searched_subset == "All Birds") {
      searched_type <- searched_subset
    }
    startpoint <- function() {
      searched_year_string <-  dlgInput("What year do you want to start from?",2005)$res
      if (!length(searched_year_string)) {
        cancelled()
      }
      else {
        searched_year_integer <- as.integer(searched_year_string)
        # is.na() is there to catch strings that were forced to be integers.
        if (!is.na(searched_year_integer) && searched_year_integer > 2004 && searched_year_integer < 2017) {
          searched_year_integer <- searched_year_integer
        }
        else {
          dlgMessage("Please select a year between 2005 and 2016 or cancel the function.")$res
          startpoint()
        }
      }
      # startpoint_number is used as the starting point for the graphing function mini_graph()
      startpoint_number <-((searched_year_integer-2005)*12)+1
    }
    startpoint_number <- startpoint()
    plot_type_string <- dlgList(c("Points only","Line only","Points and Line"),preselect = NULL, multiple = FALSE, title = "Graph Options n_n", gui = .GUI)$res
    if (!length(plot_type_string)) {
      cancelled()
    }
    else if (plot_type_string == "Points only") {
      plot_type_translated <- "p"
    }
    else if (plot_type_string == "Line only") {
      plot_type_translated <- "l"
    }
    else if (plot_type_string == "Points and Line") {
      plot_type_translated <- "o"
    }
    answers <- c(searched_site,searched_type,searched_group,searched_subset,startpoint_number,plot_type_translated)
  }
  answers <- questions()
  abun_graph <- function(site, type, group, subset, startpoint_number,plot_type) {
    print("Double-checking (for troubleshooting) n_n")
    print(noquote("_________________________________________"))
    print(paste("Site:",site))
    print(paste("Type:",type))
    print(paste("Group:",group))
    print(paste("Group Subset:",subset))
    startpoint_number <- as.integer(startpoint_number)
    print(paste("Startpoint Date Code:",startpoint_number))
    print(paste("Plot Type:",plot_type))
    # mini_graph() graphs the gathered survey data using output from mini_abundance().
    mini_graph <- function(dates,data,group,subset,site,startpoint_number,plot_type) {
      # Adjusts the title for special searched subsets 
      # (i.e. 'Not' choices for disturbance-habituated and at-risk categories, grouped-up cavity nesters).
      if (group == "Cavity Nester" || group == "Disturbances" || group == "At-Risk") {
        if (group == "Cavity Nester") {
          # 'Primary|Secondary' is the subset used for 'All Cavity Nesters'.
          if (subset == "Primary|Secondary") {
            subset <- "All"
          }
          # Adds 'All', 'Secondary', etc. to 'Cavity Nesters' for the final title.
          adjusted_title <- paste(subset," Cavity Nesters",sep="")
        }
        else {
          if (group == "Disturbances" && subset == "No") {
            subset <- "Non-disturbance-habituated"
          }
          else if (group == "At-Risk" && subset == "No") {
            subset <- "Non-At-Risk"
          }
          adjusted_title <- paste(subset," Birds",sep="")
        }
      }
      # For all other cases, the searched subset category (i.e. 'Raptors') is sufficient for a title.
      else {
        adjusted_title <- subset
      }
      final_adjusted_title <- paste(adjusted_title," at ",site," (Total Abundance)",sep="")
      ticks_startpoint <- startpoint_number-1
      ticks <- seq(ticks_startpoint,156, by=12)
      reverse_startpoint_number <- 2005+(startpoint_number-1)/12
      x_axis_title <- paste("Date Code (",startpoint_number," = January ",reverse_startpoint_number,",",startpoint_number+1," = February", reverse_startpoint_number,")")
      plot(dates,data, main=final_adjusted_title, type = plot_type, xlab = x_axis_title, ylab = "Total # of Individuals Seen", xlim = c(startpoint_number,157), xaxt = "n")
      axis(side=1,at=ticks)
      abline(v=ticks,col="lightgray")
    }
    # mini_abundance() adds together the survey data in a specific month of all requested birds in a group using their column numbers in the records CSV.
    # mini_abundance() is supposed to be called for all months in the spreadsheets. The collected data is put into a vector that's later graphed by mini_graph()
    # I don't know why plot_type is a function parameter, but at this point I'm too afraid to remove it.
     mini_abundance <- function(site, type, month, group_column_numbers,plot_type) {
      if (site == "Lost Lagoon") {
        records <- recordsLL
        # All columns are searched.
        all_species_length <- c(4:140)
      }
      else if (site == "Beaver Lake") {
        records <- recordsBL
        # All columns are searched.
        all_species_length <- c(4:111)
      }
      if (type == "All Birds") {
        species_columns <- all_species_length
      }
      else if (type == "Specific Groups") {
        species_columns <- group_column_numbers
      }
      # Grabs all individual abundances for the month and then sums it all together.
      monthly_abundance_individual <- c()
      for (species in species_columns) {
        monthly_abundance_individual <- c(monthly_abundance_individual,records[month,species])
      }
      monthly_abundance <- sum(monthly_abundance_individual)
     }
     # I probably could've combined 'All Birds' and 'Individual Species' to save space, 
     # but I kept them in separate sections for clarity. 'Specific Groups' needed to be in its own section though.
    if (type == "All Birds") {
      all_abundance_dates <- c()
      all_abundance_data <- c()
      for (month in startpoint_number:157) {
        all_abundance_data <- c(all_abundance_data,mini_abundance(site, type, month, "None"))
        all_abundance_dates <- c(all_abundance_dates,month)
      }
      mini_graph(all_abundance_dates, all_abundance_data, group, subset, site, startpoint_number,plot_type)
    }
    else if (type == "Specific Groups") {
      subset_cavity_actual <- "None"
      if (site == "Lost Lagoon") {
        info_box <- info_boxLL
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        info_box <- info_boxBL
        records <- recordsBL
      }
      if (group == "Order") {
        tier_column_number <- 3
      }
      else if (group == "Family") {
        tier_column_number <- 4
      }
      else if (group == "Tier 2") {
        tier_column_number <- 5
      }
      else if (group == "Tier 3") {
        tier_column_number <- 6
      }
      else if (group == "Disturbances") {
        tier_column_number <- 7
        # Converts 'Non-disturbance-habituated' to its actual category of 'No' in info_box.
        if (subset == "Non-disturbance-habituated") {
          subset <- "No"
        }
      }
      else if (group == "Cavity Nester") {
        tier_column_number <- 8
        # There's no category in the info_box CSV for 'All Primary', so all cavity nester categories with the word 'Primary' will be grabbed. 
        if (subset == "All Primary") {
          subset_cavity_actual <- subset
          subset <- "Primary"
        }
        # All cavity nester categories with 'Primary' or 'Secondary' in their names in info_box CSV will be grabbed.
        else if (subset == "All") {
          subset_cavity_actual <- subset
          all <- c("Primary","Secondary")
          subset <- paste(all, collapse = "|")
        }
      }
      else if (group == "At-Risk") {
        tier_column_number <- 9
        # Converts the 'Non-At-Risk' search option to its actual category of 'No' in info_box.
        if (subset == "Non-At-Risk") {
          subset <- "No"
        }
      }
      # Finds the row number in info_box of the searched group and uses it to find the corresponding alpha code for each species in the group.
      group_row_number <- which(grepl(subset,info_box[,tier_column_number]))
      group_code_factor <- info_box[group_row_number,1]
      group_code_string <- as.character(group_code_factor)
      group_code_length <- length(group_code_string)
      group_column_numbers <- c()
      # Using the alpha codes, the corresponding column numbers in the records CSV are grabbed and placed in a vector.
      for (i in 1:group_code_length) {
        group_subset <- group_code_string[i]
        group_subset_column_number <- which(grepl(group_subset,names(records)))
        group_column_numbers <- c(group_column_numbers,group_subset_column_number)
      }
      # The column numbers are used by mini_abundance() to grab the abundance data for the group in each month.
      group_abundance_dates <- c()
      group_abundance_data <- c()
      for (month in startpoint_number:157) {
        group_abundance_data <- c(group_abundance_data, mini_abundance(site, type, month, group_column_numbers))
        group_abundance_dates <- c(group_abundance_dates,month)
      }
      # For double-checking purposes, the searched group members are compared with the group members in both sites.
      # However, I didn't want to clog up the console for the bigger groups.
      if (group_code_length <= 20) {
      print(noquote("--------"))
      print("Lost Lagoon Group Members:")
      print(colnames(recordsLL)[group_column_numbers])
      print(noquote("--------"))
      print("Beaver Lake Group Members:")
      print(colnames(recordsBL)[group_column_numbers])
      print(noquote("--------"))
      print("Searched Group Members:")
      print(colnames(records)[group_column_numbers])
      }
      else {
        print("Searched Group Members: N/A; too many group members to print Q~Q")
      }
      mini_graph(group_abundance_dates,group_abundance_data,group,subset,site,startpoint_number,plot_type)
    }
    else if (type == "Individual Species") {
      if (site == "Lost Lagoon") {
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        records <- recordsBL
      }
      # Grabs the column number in the records CSV of the searched species.
      column_number <- which(names(records)==subset)
      individual_abundance_dates <- c()
      individual_abundance_data <- c()
      for (month in startpoint_number:157) {
        individual_abundance_data <- c(individual_abundance_data,records[month,column_number])
        individual_abundance_dates <- c(individual_abundance_dates,month)
      }
      mini_graph(individual_abundance_dates,individual_abundance_data,group,subset,site,startpoint_number,plot_type)
    }
  }
  abun_graph(answers[1],answers[2],answers[3],answers[4],answers[5],answers[6])
  crosscheck <- dlgMessage("Crosscheck with another species/group?","yesno")$res
  if (crosscheck == "no") {
    print("Thanks for graphing!")
  }
  else if (crosscheck == "yes") {
    par(mfrow=c(2,1))
    print(noquote("_________________________________________"))
    print(noquote("_________________________________________"))
    print("CROSSCHECKING: Graph 1")
    abun_graph(answers[1],answers[2],answers[3],answers[4],answers[5],answers[6])
    print(noquote("<----------------------------------->"))
    print("CROSSCHECKING: Graph2")
    answers2 <- questions()
    abun_graph(answers2[1],answers2[2],answers2[3],answers2[4],answers2[5],answers2[6])
    print(noquote("-----------------------------------"))
    print("Thanks for graphing!")
  }
}