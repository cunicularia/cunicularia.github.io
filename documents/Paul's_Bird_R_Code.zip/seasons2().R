library(svDialogs)
# Updating instructions: Look out for these numbers...
# 2016: Refers to the greatest year users can input before there is nothing to graph. 
# 2017: Refers to the exclusive limit of years that user can input before there is nothing to graph.
# 111: Refers to the last column in the records CSV referencing a species in Beaver Lake. Just add 1 to it for every new species seen in the site.
# 140: Refers to the last column in the records CSV referencing a species in Lost Lagoon. Just add 1 to it for every new species seen in the site.
# 156: Refers to December 2017 -- the last month of the last complete year. Just add 1 for every extra year.
# 157: Refers to January 2018 -- the last month with survey data in the spreadsheets. Just add 1 for every added month after that.
seasons2 <- function () {
  # Resets the par to default just in case graph3() modified it.
  par(mfrow=c(1,1))
  recordsBL <- read.csv("BeaverLake_Abundance.csv")
  recordsLL <- read.csv("LostLagoon_Abundance.csv")
  info_boxLL <- read.csv("LostLagoon_Info.csv")
  info_boxBL <- read.csv("BeaverLake_Info.csv")
  cancelled <- function() {
    dlgMessage("No problem! ^_^")$res
    stop("Function was cancelled.")
  }
  # questions() grabs the user input for the user's site and species of interest. 
  # These are later used by seas_graph(), which uses it to graph the seasonal abundance with two more functions:
  # mini_seasons(), which grabs the abundance for all searched species/taxa and organizes it by month; and mini_graph(), which graphs the output of mini_seasons().
  questions <- function() {
    searched_site <- dlgList(c("Lost Lagoon","Beaver Lake"),preselect = NULL, multiple = FALSE, title = "Site Options n_n", gui = .GUI)$res
    if (!length(searched_site)) {
      cancelled()
    }
    else if (searched_site == "Lost Lagoon") {
      records <- recordsLL
      info_box <- info_boxLL
    }
    else if (searched_site == "Beaver Lake") {
      records <- recordsBL
      info_box <- info_boxBL
    }
    searched_type <- dlgList(c("All Birds","Specific Groups", "Individual Species"),preselect = NULL, multiple = FALSE, title = "Type Options n_n", gui = .GUI)$res
    if (!length(searched_type)) {
      cancelled()
    }
    else if (searched_type == "All Birds") {
      searched_group <- "None"
      searched_subset <- "All Birds"
    }
    else if (searched_type == "Specific Groups") {
      searched_group <- dlgList(c("Tier 2","Tier 3","Disturbances","Cavity Nester","At-Risk","Order","Family"),preselect = NULL, multiple = FALSE, title = "Tier Options n_n", gui = .GUI)$res
      if (!length(searched_group)) {
        cancelled()
      }
      else if (searched_group == "Tier 2") {
        searched_subset <- dlgList(c("Raptors","NA Waterbirds","Anseriformes","Passeriformes","Hummingbirds","Columbiformes","Piciformes"),preselect = NULL, multiple = FALSE, title = "Tier 2 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Tier 3") {
        searched_subset <- dlgList(c("Kingfishers","Loons & Grebes","Pelecaniformes","Rallidae","Sea Birds","Shorebirds","Ducks, Dabbling","Ducks, Diving","Ducks, Perching","Ducks, Sea","Geese & Swans","Aerial Insectivores","Forest Birds","Disturbance-adapted"),preselect = NULL, multiple = FALSE, title = "Tier 3 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Disturbances") {
        searched_subset <- dlgList(c("Disturbance-habituated","Non-disturbance-habituated"),preselect = NULL, multiple = FALSE, title = "Disturbance Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "At-Risk") {
        searched_subset <- dlgList(c("At-Risk","Non-At-Risk"),preselect = NULL, multiple = FALSE, title = "At-Risk Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Cavity Nester") {
        searched_subset <- dlgList(c("All","All Primary","Strong Primary","Weak Primary","Secondary"),preselect = NULL, multiple = FALSE, title = "Cavity Nester Options n_n", gui = .GUI)$res
      }
      # column_check checks the columns in info_box that list out order and family and figures out if the user input is in there.
      else if (searched_group == "Order" || searched_group == "Family") {
        if (searched_group == "Order") {
          example <- "Passeriformes"
          column_check <- 3
        }
        else if (searched_group == "Family") {
          example <- "Rallidae"
          column_check <- 4
        }
        searched_subset <- dlgInput("What taxon are you interested in?",example)$res
        if (!length(searched_subset)) {
          cancelled()
        }
        else if (searched_subset %in% info_box[,column_check]) {
          searched_subset <- searched_subset
        }
        # If the input isn't recognized, users are stuck in a loop until they input a valid one or they cancel the function.
        else {
          error_loop <- function() {
            dlgMessage("Sorry, that taxon was not found in the records. Please search again or cancel.")
            searched_subset <- dlgInput("What's the code of the taxon you're interested in?", searched_subset)$res
            if (!length(searched_subset)) {
              cancelled()
            }
            else if (searched_subset %in% info_box[,column_check]) {
              searched_subset <- searched_subset
            }
            else {
              error_loop()
            }
          }
          searched_subset <- error_loop()
        }
      }
    }
    else if (searched_type == "Individual Species") {
      searched_group <- "None"
      searched_subset <- dlgInput("What's the code of the species you're interested in?","All Birds")$res
      # It's a pain to remember to put in alpha codes in all caps, so capital_searched_subset adjusts for it.
      capital_searched_subset <- toupper(searched_subset)
      if (!length(searched_subset)) {
        cancelled()
      }
      else if (searched_subset == "All Birds" || searched_subset %in% colnames(records)) {
        searched_subset <- searched_subset
      }
      else if (capital_searched_subset %in% colnames(records)) {
        searched_subset <- capital_searched_subset
      }
      else {
        error_loop <- function() {
          dlgMessage("Sorry, that species was not found in the records. Please search again or cancel.")
          searched_subset <- dlgInput("What's the code of the species you're interested in?", searched_subset)$res
          capital_searched_subset <- toupper(searched_subset)
          if (!length(searched_subset)) {
            cancelled()
          }
          else if (searched_subset == "All Birds" || searched_subset %in% colnames(records)) {
            searched_subset <- searched_subset
          }
          else if (capital_searched_subset %in% colnames(records)) {
            searched_subset <- capital_searched_subset
          }
          else {
            error_loop()
          }
        }
        searched_subset <- error_loop()
      }
    }
    # This accounts for how 'All Birds' can be inputted in both the 'All Birds' and 'Individual Species' sections without repeating code.
    if (searched_subset == "All Birds") {
      searched_type <- searched_subset
    }
    answers <- c(searched_site,searched_type,searched_group,searched_subset)
  }
  answers <- questions()
  seas_graph <- function(site, type, group, subset) {
    print("Double-checking (for troubleshooting) n_n")
    print(noquote("_________________________________________"))
    print(paste("Site:",site))
    print(paste("Type:",type))
    print(paste("Group:",group))
    print(paste("Group Subset:",subset))
    mini_graph <- function(dates,data,group,subset,site) {
      # This next sections adjusts the final graph title for special categories that would require it.
      if (group == "Cavity Nester" || group == "Disturbances" || group == "At-Risk") {
        if (group == "Cavity Nester") {
          if (subset == "Primary|Secondary") {
            subset <- "All"
          }
          adjusted_title <- paste(subset," Cavity Nesters",sep="")
        }
        else {
          if (group == "Disturbances" && subset == "No") {
            subset <- "Non-disturbance-habituated"
          }
          else if (group == "At-Risk" && subset == "No") {
            subset <- "Non-At-Risk"
          }
          adjusted_title <- paste(subset," Birds",sep="")
        }
      }
      else {
        adjusted_title <- subset
      }
      final_adjusted_title <- paste(adjusted_title," at ",site," (Seasonal Abundance)",sep="")
      ticks <- c(1:12)
      plot(dates,data, main=final_adjusted_title, xlab = "Month (1 = Jan, 2 = Feb)",ylab = "Total # of Individuals Seen", xaxt = "n")
      axis(side=1,at=ticks)
    }
    # mini_seasons() gathers the abundance value of a certain month for all searched species (denoted by the group_column_numbers, with the column numbers being in the records CSV).
    mini_seasons <- function(site, type, month, group_column_numbers) {
      if (site == "Lost Lagoon") {
        records <- recordsLL
        all_species_length <- c(4:140)
      }
      else if (site == "Beaver Lake") {
        records <- recordsBL
        all_species_length <- c(4:111)
      }
      # all_species_length basically means searching all columns for the species.
      if (type == "All Birds") {
        species_columns <- all_species_length
      }
      else if (type == "Specific Groups") {
        species_columns <- group_column_numbers
      }
      monthly_abundance_individual <- c()
      for (species in species_columns) {
        monthly_abundance_individual <- c(monthly_abundance_individual,records[month,species])
      }
      monthly_abundance <- sum(monthly_abundance_individual)
    }
    if (type == "All Birds") {
      all_abundance_dates <- c()
      all_abundance_data <- c()
      for (month in 1:157) {
        all_abundance_data <- c(all_abundance_data,mini_seasons(site, type, month, "None"))
        all_abundance_dates <- c(all_abundance_dates,month)
      }
      # The following lines change all gathered dates to numerical months.
      all_abundance_dates_modulo <- all_abundance_dates %% 12
      all_abundance_months <- c()
      for (index in 1:length(all_abundance_dates_modulo)) {
        if (all_abundance_dates_modulo[index] == 0) {
          all_abundance_months <- c(all_abundance_months, 12)
        }
        else {
          all_abundance_months <- c(all_abundance_months, all_abundance_dates_modulo[index])
        }
      }
      mini_graph(all_abundance_months, all_abundance_data, group, subset, site)
    }
    else if (type == "Specific Groups") {
      subset_cavity_actual <- "None"
      if (site == "Lost Lagoon") {
        info_box <- info_boxLL
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        info_box <- info_boxBL
        records <- recordsBL
      }
      if (group == "Order") {
        tier_column_number <- 3
      }
      else if (group == "Family") {
        tier_column_number <- 4
      }
      else if (group == "Tier 2") {
        tier_column_number <- 5
      }
      else if (group == "Tier 3") {
        tier_column_number <- 6
      }
      else if (group == "Disturbances") {
        tier_column_number <- 7
        if (subset == "Non-disturbance-habituated") {
          subset <- "No"
        }
      }
      else if (group == "Cavity Nester") {
        tier_column_number <- 8
        # To search for all primary cavity nesters, all cavity nester categories in info_box that contains the word 'Primary' are grabbed.
        if (subset == "All Primary") {
          subset_cavity_actual <- subset
          subset <- "Primary"
        }
        # To search for all cavity nesters, all categories with 'Primary' or 'Secondary' are grabbed.
        else if (subset == "All") {
          subset_cavity_actual <- subset
          all <- c("Primary","Secondary")
          subset <- paste(all, collapse = "|")
        }
      }
      else if (group == "At-Risk") {
        tier_column_number <- 9
        if (subset == "Non-At-Risk") {
          subset <- "No"
        }
      }
      # In the searched tier's column in info_box, the category is searched for and the row numbers where the category appears are found.
      # Then, they are translated to the searched species' alpha codes.
      group_row_number <- which(grepl(subset,info_box[,tier_column_number]))
      group_code_factor <- info_box[group_row_number,1]
      group_code_string <- as.character(group_code_factor)
      group_code_length <- length(group_code_string)
      group_column_numbers <- c()
      # The alpha codes are then searched for to grab their respective column numbers in the records CSV. 
      # These column numbers will be plugged into mini_seasons().
      for (i in 1:group_code_length) {
        group_subset <- group_code_string[i]
        group_subset_column_number <- which(grepl(group_subset,names(records)))
        group_column_numbers <- c(group_column_numbers,group_subset_column_number)
      }
      group_abundance_data <- c()
      group_abundance_dates <- c()
      for (month in 1:157) {
        group_abundance_data <- c(group_abundance_data,mini_seasons(site, type, month, group_column_numbers))
        group_abundance_dates <- c(group_abundance_dates,month)
      }
      group_abundance_dates_modulo <- group_abundance_dates %% 12
      group_abundance_months <- c()
      for (index in 1:length(group_abundance_dates_modulo)) {
        if (group_abundance_dates_modulo[index] == 0) {
          group_abundance_months <- c(group_abundance_months, 12)
        }
        else {
          group_abundance_months <- c(group_abundance_months, group_abundance_dates_modulo[index])
        }
      }
      # For double-checking purposes, the searched group's species are printed to the console and compared to the searched group members in both sites.
      # I didn't want to clog up the console though, so if there are more than 19, I bailed out.
      if (group_code_length <= 20) {
        print(noquote("--------"))
        print("Lost Lagoon Group Members:")
        print(colnames(recordsLL)[group_column_numbers])
        print(noquote("--------"))
        print("Beaver Lake Group Members:")
        print(colnames(recordsBL)[group_column_numbers])
        print(noquote("--------"))
        print("Searched Group Members:")
        print(colnames(records)[group_column_numbers])
      }
      else {
        print("Searched Group Members: N/A; too many group members to print Q~Q")
      }
      mini_graph(group_abundance_months,group_abundance_data,group,subset,site)
    }
    else if (type == "Individual Species") {
      if (site == "Lost Lagoon") {
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        records <- recordsBL
      }
      column_number <- which(names(records)==subset)
      individual_abundance_dates <- c()
      individual_abundance_data <- c()
      for (month in 1:157) {
        individual_abundance_data <- c(individual_abundance_data,records[month,column_number])
        individual_abundance_dates <- c(individual_abundance_dates,month)
      }
      individual_abundance_dates_modulo <- individual_abundance_dates %% 12
      individual_abundance_months <- c()
      for (index in 1:length(individual_abundance_dates_modulo)) {
        if (individual_abundance_dates_modulo[index] == 0) {
          individual_abundance_months <- c(individual_abundance_months, 12)
        }
        else {
          individual_abundance_months <- c(individual_abundance_months, individual_abundance_dates_modulo[index])
        }
      }
      mini_graph(individual_abundance_months,individual_abundance_data, group, subset, site)
    }
  }
  seas_graph(answers[1],answers[2],answers[3],answers[4])
  print(noquote("--------"))
  print("Thanks for graphing ^_^")
}