library(svDialogs)
# Updating instructions: Look out for these numbers...
# Actually, I think it should be future-proof.
info2 <- function() {
  recordsBL <- read.csv("BeaverLake_Abundance.csv")
  recordsLL <- read.csv("LostLagoon_Abundance.csv")
  info_boxLL <- read.csv("LostLagoon_Info.csv")
  info_boxBL <- read.csv("BeaverLake_Info.csv")
  cancelled <- function() {
    dlgMessage("No problem! ^_^")$res
    stop("Function was cancelled.")
  }
  # questions() grabs two things from the user: the site and species/taxon of interest.
  # The output of questions() is later plugged into mini_info().
  questions <- function() {
    searched_site <- dlgList(c("Lost Lagoon","Beaver Lake"),preselect = NULL, multiple = FALSE, title = "Site Options n_n", gui = .GUI)$res
    if (!length(searched_site)) {
      cancelled()
    }
    else if (searched_site == "Lost Lagoon") {
      records <- recordsLL
      info_box <- info_boxLL
    }
    else if (searched_site == "Beaver Lake") {
      records <- recordsBL
      info_box <- info_boxBL
    }
    searched_type <- dlgList(c("All Birds","Specific Groups", "Individual Species"),preselect = NULL, multiple = FALSE, title = "Type Options n_n", gui = .GUI)$res
    if (!length(searched_type)) {
      cancelled()
    }
    else if (searched_type == "All Birds") {
      searched_group <- "None"
      searched_subset <- "All Birds"
    }
    else if (searched_type == "Specific Groups") {
      searched_group <- dlgList(c("Tier 2","Tier 3","Disturbances","Cavity Nester","At-Risk","Order","Family"),preselect = NULL, multiple = FALSE, title = "Tier Options n_n", gui = .GUI)$res
      if (!length(searched_group)) {
        cancelled()
      }
      else if (searched_group == "Tier 2") {
        searched_subset <- dlgList(c("Raptors","NA Waterbirds","Anseriformes","Passeriformes","Hummingbirds","Columbiformes","Piciformes"),preselect = NULL, multiple = FALSE, title = "Tier 2 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Tier 3") {
        searched_subset <- dlgList(c("Kingfishers","Loons & Grebes","Pelecaniformes","Rallidae","Sea Birds","Shorebirds","Ducks, Dabbling","Ducks, Diving","Ducks, Perching","Ducks, Sea","Geese & Swans","Aerial Insectivores","Forest Birds","Disturbance-adapted"),preselect = NULL, multiple = FALSE, title = "Tier 3 Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Disturbances") {
        searched_subset <- dlgList(c("Disturbance-habituated","Non-disturbance-habituated"),preselect = NULL, multiple = FALSE, title = "Disturbance Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "At-Risk") {
        searched_subset <- dlgList(c("At-Risk","Non-At-Risk"),preselect = NULL, multiple = FALSE, title = "At-Risk Options n_n", gui = .GUI)$res
      }
      else if (searched_group == "Cavity Nester") {
        searched_subset <- dlgList(c("All","All Primary","Strong Primary","Weak Primary","Secondary"),preselect = NULL, multiple = FALSE, title = "Cavity Nester Options n_n", gui = .GUI)$res
      }
      # column_check refers to the columms in info_box that list the orders and families. 
      # column_check is used to determine whether the user input is valid.
      else if (searched_group == "Order" || searched_group == "Family") {
        if (searched_group == "Order") {
          example <- "Passeriformes"
          column_check <- 3
        }
        else if (searched_group == "Family") {
          example <- "Rallidae"
          column_check <- 4
        }
        searched_subset <- dlgInput("What taxon are you interested in?",example)$res
        if (!length(searched_subset)) {
          cancelled()
        }
        else if (searched_subset %in% info_box[,column_check]) {
          searched_subset <- searched_subset
        }
        # The loop catches inputs that aren't valid and traps users in a loop until they input a correct one or cancel.
        else {
          error_loop <- function() {
            dlgMessage("Sorry, that taxon was not found in the records. Please search again or cancel.")
            searched_subset <- dlgInput("What's the code of the taxon you're interested in?", searched_subset)$res
            if (!length(searched_subset)) {
              cancelled()
            }
            else if (searched_subset %in% info_box[,column_check]) {
              searched_subset <- searched_subset
            }
            else {
              error_loop()
            }
          }
          searched_subset <- error_loop()
        }
      }
    }
    else if (searched_type == "Individual Species") {
      searched_group <- "None"
      searched_subset <- dlgInput("What's the code of the species you're interested in?","All Birds")$res
      # If the user wants to type everything in lowercase, I made it uppercase so it doesn't break.
      capital_searched_subset <- toupper(searched_subset)
      if (!length(searched_subset)) {
        cancelled()
      }
      else if (searched_subset == "All Birds" || searched_subset %in% colnames(records)) {
        searched_subset <- searched_subset
      }
      else if (capital_searched_subset %in% colnames(records)) {
        searched_subset <- capital_searched_subset
      }
      # Users are trapped in a loop until a valid alpha code is inputted or the function is cancelled.
      else {
        error_loop <- function() {
          dlgMessage("Sorry, that species was not found in the records. Please search again or cancel.")
          searched_subset <- dlgInput("What's the code of the species you're interested in?", searched_subset)$res
          capital_searched_subset <- toupper(searched_subset)
          if (!length(searched_subset)) {
            cancelled()
          }
          else if (searched_subset == "All Birds" || searched_subset %in% colnames(records)) {
            searched_subset <- searched_subset
          }
          else if (capital_searched_subset %in% colnames(records)) {
            searched_subset <- capital_searched_subset
          }
          else {
            error_loop()
          }
        }
        searched_subset <- error_loop()
      }
    }
    # If 'All Birds' is inputted via the 'All Birds' or 'Individual Species' option, it's all good.
    if (searched_subset == "All Birds") {
      searched_type <- searched_subset
    }
    answers <- c(searched_site,searched_type,searched_group,searched_subset)
  }
  answers <-questions()
  mini_info <- function(site,type,group,subset) {
    cat("Hi! You're looking for...\n")
    cat(noquote("_________________________________________\n"))
    cat("Site:",site,"\n")
    cat("Type:",type,"\n")
    cat("Group:",group,"\n")
    cat("Group Subset:",subset,"\n")
    if (site == "Lost Lagoon") {
      info_box <- info_boxLL
    }
    else if (site == "Beaver Lake") {
      info_box <- info_boxBL
    }
    # 'All Birds' gives the user the total richness, a view of the full info_box CSV, and the unique species in both sites.
    if (type == "All Birds") {
      cat(noquote("------------------------------------\n"))
      cat("There have been around ",length(info_box[,1])," species/entries recorded in ",site,".\nThis number includes subspecies and unidentified species.\nLoading up the spreadsheet for ",site," birds...\n",sep="")
      if (site == "Lost Lagoon") {
        View(info_boxLL)
      }
      else if (site == "Beaver Lake") {
        View(info_boxBL)
      }
      # Finds out the species LL has that BL doesn't.
      all_LL_vs_BL <- setdiff(info_boxLL[,1],info_boxBL[,1])
      cat(noquote("------------------------------------\n"))
      cat("The following",length(all_LL_vs_BL),"species/entries have been spotted in Lost Lagoon but not Beaver Lake:\n")
      print(all_LL_vs_BL)
      cat(noquote("------------------------------------\n"))
      # Finds out the species BL has that LL doesn't.
      all_BL_vs_LL <- setdiff(info_boxBL[,1],info_boxLL[,1])
      cat("The following",length(all_BL_vs_LL),"species/entries have been spotted in Beaver Lake but not Lost Lagoon:\n")
      print(all_BL_vs_LL)
      dlgMessage("Please check the console ^_^")
    }
    # 'Specific Groups' lists out all the members of the searched group that have been seen at the site.
    else if (type == "Specific Groups") {
      subset_cavity_actual <- "None"
      if (site == "Lost Lagoon") {
        info_box <- info_boxLL
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        info_box <- info_boxBL
        records <- recordsBL
      }
      if (group == "Order") {
        tier_column_number <- 3
      }
      else if (group == "Family") {
        tier_column_number <- 4
      }
      else if (group == "Tier 2") {
        tier_column_number <- 5
      }
      else if (group == "Tier 3") {
        tier_column_number <- 6
      }
      else if (group == "Disturbances") {
        tier_column_number <- 7
        if (subset == "Non-disturbance-habituated") {
          subset <- "No"
        }
      }
      else if (group == "Cavity Nester") {
        tier_column_number <- 8
        if (subset == "All Primary") {
          subset_cavity_actual <- subset
          subset <- "Primary"
        }
        else if (subset == "All") {
          subset_cavity_actual <- subset
          all <- c("Primary","Secondary")
          subset <- paste(all, collapse = "|")
        }
      }
      else if (group == "At-Risk") {
        tier_column_number <- 9
        if (subset == "Non-At-Risk") {
          subset <- "No"
        }
      }
      # Grabs the row numbers in info_box that correspond to the species in the searched group.
      # Using these row numbers, their alpha codes and English/common names are obtained.
      group_row_number <- which(grepl(subset,info_box[,tier_column_number]))
      group_code_factor <- info_box[group_row_number,1]
      group_code_string <- as.character(group_code_factor)
      group_name_factor <- info_box[group_row_number,2]
      group_name_string <- as.character(group_name_factor)
      group_length <- length(group_code_string)
      cat(group_length," members of the subset were found at ",site,":\n",sep="")
      # I don't want to clog consoles, so if there are a lot of species in the group, their names won't be printed unless user inputs that they're okay with it.
      if (group_length > 20) {
        group_overflow_message <- paste("Just a heads-up, there are a lot of (i.e. ",group_length,") species/entries in this group. Proceeding may clog up your console.",sep="") 
        dlgMessage(group_overflow_message)$res
        group_overflow_check <- dlgMessage("Would you like to proceed?","yesno")$res
        if(group_overflow_check == "no") {
          cat("Searched Group Members: N/A; too many group members to print Q~Q\n")
        }
        else if (group_overflow_check == "yes") {
          print(paste(group_code_string,":", group_name_string))
        }
      }
      else {
        print(paste(group_code_string,":", group_name_string))
      }
    }
    # 'Individual Species' gives out information about the searched species.
    # Their locations on the info_box and records CSVs are also given out.
    # It makes it a bit easier to find species when doing the fast() function.
    # As a bonus, their presence in BL or LL is listed.
    else if (type == "Individual Species") {
      if (site == "Lost Lagoon") {
        info_box <- info_boxLL
        records <- recordsLL
      }
      else if (site == "Beaver Lake") {
        info_box <- info_boxBL
        records <- recordsBL
      }
      individual_row_number <- which(grepl(subset,info_box[,1]))
      cat(noquote("------------------------------------\n"))
      print(paste("Row # on the",site,"info_box spreadsheet:",individual_row_number),quote=FALSE)
      print(paste("Column # on the",site,"records spreadsheet:",which(names(records)==subset)),quote=FALSE)
      print(paste("Alpha Code:",info_box[individual_row_number,1]),quote=FALSE)
      print(paste("English/Common Name:",info_box[individual_row_number,2]),quote=FALSE)
      print(paste("Order:",info_box[individual_row_number,3]),quote=FALSE)
      print(paste("Family:",info_box[individual_row_number,4]),quote=FALSE)
      print(paste("Tier 2:",info_box[individual_row_number,5]),quote=FALSE)
      print(paste("Tier 3:",info_box[individual_row_number,6]),quote=FALSE)
      print(paste("Disturbance-habituated?:",info_box[individual_row_number,7]),quote=FALSE)
      print(paste("Cavity Nester Category:",info_box[individual_row_number,8]),quote=FALSE)
      print(paste("At-Risk?:",info_box[individual_row_number,9]),quote=FALSE)
      lost_lagoon_space <-" not"
      lost_lagoon_check <- subset %in% info_boxLL[,1]
      if (lost_lagoon_check) {
        lost_lagoon_space <- ""
      }
      beaver_lake_space <- " not"
      beaver_lake_check <- subset %in% info_boxBL[,1]
      if (beaver_lake_check) {
        beaver_lake_space <- ""
      }
      print(paste("This species has",lost_lagoon_space," been observed at Lost Lagoon.",sep=""),quote=FALSE)
      print(paste("This species has",beaver_lake_space," been observed at Beaver Lake.",sep=""),quote=FALSE)
    }
  }
  mini_info(answers[1],answers[2],answers[3],answers[4])
  cat(noquote("------------------------------------\n"))
  cat("Thanks for searching! \\(^v^)/")
}